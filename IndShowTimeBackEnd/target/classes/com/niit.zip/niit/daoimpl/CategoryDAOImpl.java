package com.niit.daoimpl;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;

import com.niit.dao.CategoryDAO;
import com.niit.model.CategoryModel;

public class CategoryDAOImpl implements CategoryDAO
{
	@Autowired
	SessionFactory sessionFactory;
	
	public CategoryDAOImpl(SessionFactory sessionFactory) {
		// TODO Auto-generated constructor stub
		this.sessionFactory=sessionFactory;
	}
	public List<CategoryModel> getAllCategoryDetails() {
		Session session=sessionFactory.openSession();
		List<CategoryModel> products =null;
		session.beginTransaction();
		products= session.createQuery("from CategoryDetails").list();   
		session.getTransaction().commit();
		  return products;
	}
/*
	public CategoryModel getCategoryDetail(int id) {
		CategoryModel product = (CategoryModel) getCurrentSession().get(CategoryModel.class, id);

        return product;
	}

	public void updateCategoryDetail(CategoryModel obj) {
		getCurrentSession().update(obj);
		
	}*/

	public void addCategory(CategoryModel obj) {
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		session.persist(obj);
		session.getTransaction().commit();
		
	}

	/*public void deleteCategory(int catId) {
		getCurrentSession().delete(catId);
		
	}*/
	
}