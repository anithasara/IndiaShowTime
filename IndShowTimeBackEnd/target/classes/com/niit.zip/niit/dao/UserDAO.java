package com.niit.dao;

import java.util.List;

import org.springframework.stereotype.Repository;
import com.niit.model.UserModel;


public interface UserDAO
{
	List<UserModel> getAllUserDetails();
	UserModel getUserDetail(String id);
	void updateUserDetails(UserModel obj);
	void addUser(UserModel obj);
	public void delete(UserModel entity);
}