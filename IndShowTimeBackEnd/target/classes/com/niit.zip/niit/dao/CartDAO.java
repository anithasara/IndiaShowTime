package com.niit.dao;


import java.util.List;
import org.springframework.stereotype.Repository;

import com.niit.model.CartModel;

public interface CartDAO
{
	List<CartModel> getAllCartDetails();
	CartModel getCartDetail(String id);
	void updateCartDetails(CartModel obj);
	void addCart(CartModel obj);
	public void delete(CartModel entity);
}