package com.niit.dao;


import java.util.List;
import org.springframework.stereotype.Repository;

import com.niit.model.OrdersModel;


public interface OrdersDAO
{
	List<OrdersModel> getAllOrderDetails();
	OrdersModel getOrderDetail(String id);
	void updateOrderDetails(OrdersModel obj);
	void addOrder(OrdersModel obj);
	public void delete(OrdersModel entity);
}