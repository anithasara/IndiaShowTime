package com.niit.dao;

import java.util.List;
import org.springframework.stereotype.Repository;
import com.niit.model.SupplierModel;


public interface SupplierDAO
{
	List<SupplierModel> getAllSupplierDetails();
	//SupplierModel getSupplierDetail(String id);
	//void updateSupplierDetails(SupplierModel obj);*/
	void addSupplier(SupplierModel obj);
	//public void delete(SupplierModel entity);
}