package com.niit.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name="CategoryDetails",uniqueConstraints = {
		@UniqueConstraint(columnNames = "category_Id")})
public class CategoryModel implements Serializable
{
	@Id
	@Column(name="category_Id")
	private Integer categoryId;
	@Column(name="category_Name")
	private String categoryName;
	@OneToMany(mappedBy = "prodCategory",cascade=CascadeType.ALL,fetch = FetchType.LAZY)
	@Column(name="category_Products")
	private Set<ProductModel> categoryProducts=new HashSet<ProductModel>(
			0);

	public CategoryModel()
	{
		
	}
	/*public CategoryModel(Integer categoryId,String categoryName)
	{
		this.categoryId=categoryId;
		this.categoryName=categoryName;
		this.categoryProducts=null;
	}*/
    public CategoryModel(Integer categoryId, String categoryName, Set<ProductModel> categoryProducts) {
		super();
		this.categoryId = categoryId;
		this.categoryName = categoryName;
		this.categoryProducts = categoryProducts;
	}
	//Getter and Setter methods for Product Quantity
    public void setCategoryId(Integer categoryId)
	{
		this.categoryId=categoryId;
	}
    @Column(name = "category_Id", unique = true, nullable = false)
    public Integer getCategoryId()
    {
    	return this.categoryId;
    }
    
    //Getter and Setter methods for Product Category
    public void setCategoryName(String categoryName)
	{
		this.categoryName=categoryName;
	}
    public String getCategoryName()
    {
    	return this.categoryName;
    }
    
    //Getter and Setter methods for Product Supplier
  
    public void setCategoryProducts(Set<ProductModel> categoryProducts)
	{
		this.categoryProducts=categoryProducts;
	}
    
 
    public Set<ProductModel> getCategoryProducts()
    {
    	return this.categoryProducts;
    }
}
