package com.niit.model;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name="OrderDetails",uniqueConstraints = {
		@UniqueConstraint(columnNames = "order_Id")})
public class OrdersModel implements Serializable
{
	@Id
	@Column(name="order_Id")
	private Integer orderId;
	@Column(name="order_User_Id")
	private String orderUserId;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="userId")
	private UserModel orderUserDetails;
	@Column(name="order_Payment")
	private String orderPayment;
	@Column(name="order_Total")
	private double orderTotal;
	
	public OrdersModel()
	{
		
	}
	public OrdersModel(Integer orderId,String orderUserId,UserModel orderUserDetails,String orderPayment,double orderTotal)
	{
		this.orderId=orderId;
		this.orderUserId=orderUserId;
		this.orderUserDetails=orderUserDetails;
		this.orderPayment=orderPayment;
		this.orderTotal=orderTotal;
		
	}
	//Getter and Setter methods for Product ID
		public void setorderId(Integer orderId)
		{
			this.orderId=orderId;
		}
		@Column(name = "order_Id", unique = true, nullable = false)
	    public Integer getorderId()
	    {
	    	return this.orderId;
	    }
	    
		//Getter and Setter methods for Product Brand
	    public void setOrderUserId(String orderUserId)
		{
			this.orderUserId=orderUserId;
		}
	    public String getOrderUserId()
	    {
	    	return this.orderUserId;
	    }
	    //Getter and Setter methods for Product Brand
	    public void setOrderUserDetails(UserModel orderUserDetails)
		{
			this.orderUserDetails=orderUserDetails;
		}
	    
	    public UserModel getOrderUserDetails()
	    {
	    	return this.orderUserDetails;
	    }
	    
	    //Getter and Setter methods for Product Name
	    public void setOrderPayment(String orderPayment)
		{
			this.orderPayment=orderPayment;
		}
	    
	    public String getOrderPayment()
	    {
	    	return this.orderPayment;
	    }
	    
	    //Getter and Setter methods for Product Description
	    public void setOrderTotal(double orderTotal)
		{
			this.orderTotal=orderTotal;
		}
	    public double getOrderTotal()
	    {
	    	return orderTotal;
	    }
}