package com.niit.model;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name="CartDetails",uniqueConstraints = {
		@UniqueConstraint(columnNames = "cart_Id")})
public class CartModel implements Serializable
{
	@Id
	@Column(name="cart_Id")
	private Integer cartId;
	@Column(name="cart_Supplier_Id")
	private Integer cartSupplierId;
	@Column(name="cart_Product_Id")
	private Integer cartProductId;
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="userId")
	private UserModel cartUserDetails;
	@Column(name="cart_Price")
	private int cartPrice;
	@Column(name="cart_Quantity")
	private int cartQuantity;
	@Column(name="cart_Status")
	private String cartStatus;
	
	public CartModel()
	{
		
	}
	public CartModel(Integer cartId,Integer cartSupplierId,Integer cartProductId,
			UserModel cartUserDetails,int cartPrice,int cartQuantity,String cartStatus)
	{
		this.cartId=cartId;
		this.cartSupplierId=cartSupplierId;
		this.cartProductId=cartProductId;
		this.cartUserDetails=cartUserDetails;
		this.cartPrice=cartPrice;
		this.cartQuantity=cartQuantity;
		this.cartStatus=cartStatus;
	}
	//Getter and Setter methods for Product ID
		public void setCartId(Integer cartId)
		{
			this.cartId=cartId;
		}
		@Column(name = "cart_Id", unique = true, nullable = false)
	    public Integer getProdId()
	    {
	    	return this.cartId;
	    }
	    
	    //Getter and Setter methods for Product Brand
	    public void setcartSupplierId(Integer cartSupplierId)
		{
			this.cartSupplierId=cartSupplierId;
		}
	    public Integer getcartSupplierId()
	    {
	    	return this.cartSupplierId;
	    }
	    
	    //Getter and Setter methods for Product Name
	    public void setcartProductId(Integer cartProductId)
		{
			this.cartProductId=cartProductId;
		}
	    
	    public Integer getCartProductId()
	    {
	    	return this.cartProductId;
	    }
	    
	    //Getter and Setter methods for Product Description
	    public void setCartUserDetails(UserModel cartUserDetails)
		{
			this.cartUserDetails=cartUserDetails;
		}
		
	    public UserModel getCartUserDetails()
	    {
	    	return this.cartUserDetails;
	    }
	    
	    //Getter and Setter methods for Product Price
	    public void getCartPrice(int cartPrice)
		{
			this.cartPrice=cartPrice;
		}
	    public int getCartPrice()
	    {
	    	return this.cartPrice;
	    }
	    
	    //Getter and Setter methods for Product Quantity
	    public void setCartQuantity(int cartQuantity)
		{
			this.cartQuantity=cartQuantity;
		}
	    public int getCartQuantity()
	    {
	    	return this.cartQuantity;
	    }
	    
	    //Getter and Setter methods for Product Category
	    public void getCartStatus(String cartStatus)
		{
			this.cartStatus=cartStatus;
		}
	    public String setCartStatus()
	    {
	    	return this.cartStatus;
	    }
	    
}